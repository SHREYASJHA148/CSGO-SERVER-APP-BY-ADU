// Global variables
let servers = [];
let refreshInterval;
let refreshTimer = 20;

// Map images for different CS:GO/CS2 maps
const mapImages = {
    'de_mirage': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_mirage.png',
    'de_dust2': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_dust2.png',
    'de_overpass': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_overpass.png',
    'de_nuke': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_nuke.png',
    'de_vertigo': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_vertigo.png',
    'de_inferno': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_inferno.png',
    'de_ancient': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_ancient.png',
    'de_anubis': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_anubis.png',
    'de_train': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_train.png',
    'de_cache': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_cache.png',
    'de_tuscan': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_tuscan.png',
    'de_cbble': 'https://raw.githubusercontent.com/MurkyYT/cs2-map-icons/main/images/de_cbble.png'
};

/**
 * Get player count color based on current/max players
 * @param {number} current - Current players
 * @param {number} max - Maximum players
 * @param {boolean} online - Server online status
 * @returns {string} CSS class for color
 */
function getPlayerCountColor(current, max, online) {
    if (!online) return 'players-offline';
    if (current === max) return 'players-full';
    if (current >= max * 0.8) return 'players-high';
    if (current >= max * 0.5) return 'players-medium';
    return 'players-low';
}

/**
 * Get map image URL
 * @param {string} mapName - Map name
 * @returns {string} Map image URL
 */
function getMapImage(mapName) {
    return mapImages[mapName] || mapImages['de_mirage'];
}

/**
 * Create server HTML element
 * @param {Object} server - Server object with all properties
 * @param {string} layout - Layout type (primary, secondary, global)
 * @returns {string} HTML string
 */
function createServerElement(server, layout = 'primary') {
    const mapImage = getMapImage(server.map);
    const playerColor = getPlayerCountColor(server.players, server.maxPlayers, server.online);
    const offlineClass = !server.online ? 'server-offline' : '';
    
    if (layout === 'conneqt') {
        // Conneqt server layout - premium style
        return `
            <div class="server-entry p-5 rounded-lg border border-purple-500/20 bg-gradient-to-br from-purple-500/5 to-pink-500/5 ${offlineClass}" data-ip="${server.ip}">
                <div class="map-overlay" style="background-image: url('${mapImage}');"></div>
                <div class="relative z-10">
                    <div class="flex items-center justify-between mb-3">
                        <h4 class="font-bold text-sm text-white uppercase">${server.name}</h4>
                        <span class="text-[8px] font-black bg-purple-500/20 text-purple-400 px-2 py-1 rounded">PREMIUM</span>
                    </div>
                    <p class="text-[9px] text-zinc-500 font-mono mb-4">${server.ip}</p>
                    ${server.online ? `
                        <div class="flex justify-between items-center mb-4">
                            <span class="text-[10px] text-zinc-600">Players: <span class="player-count ${playerColor} font-black">${server.players}/${server.maxPlayers}</span></span>
                            <span class="text-[10px] text-zinc-600">${server.map}</span>
                        </div>
                    ` : `
                        <div class="mb-4">
                            <span class="text-[10px] players-offline font-black">Server Offline</span>
                        </div>
                    `}
                </div>
                <button onclick="connect('${server.ip}')" class="w-full py-2 text-[9px] font-black uppercase tracking-widest border border-purple-500/30 bg-purple-500/10 hover:bg-purple-500 hover:text-black transition-all connect-btn relative z-10">
                    ${server.online ? 'Connect' : 'Offline'}
                </button>
            </div>
        `;
    } else if (layout === 'primary') {
        // Large server cards (Delhi Primary #1, #2)
        return `
            <div class="server-entry p-6 rounded-xl flex items-center justify-between group ${offlineClass}" data-ip="${server.ip}">
                <div class="map-overlay" style="background-image: url('${mapImage}');"></div>
                <div class="flex items-center gap-8 relative z-10">
                    <div class="text-center border-r border-white/10 pr-8">
                        <p class="text-[10px] font-bold text-zinc-500 uppercase">Players</p>
                        <p class="text-xl font-black player-count ${playerColor}">
                            ${server.online ? `${server.players}/${server.maxPlayers}` : 'Offline'}
                        </p>
                    </div>
                    <div>
                        <h4 class="font-black text-white italic tracking-wide text-xl uppercase">${server.name}</h4>
                        <p class="text-xs text-zinc-500 font-mono mt-1">${server.ip}</p>
                        ${server.online ? `
                            <div class="flex items-center gap-4 mt-2">
                                <span class="text-[9px] text-zinc-600">Map: <span class="text-white">${server.map}</span></span>
                                <span class="text-[9px] text-zinc-600">Ping: <span class="text-white">${server.ping}ms</span></span>
                            </div>
                        ` : ''}
                    </div>
                </div>
                <button onclick="connect('${server.ip}')" class="connect-btn px-10 py-4 text-[10px] font-black uppercase tracking-widest relative z-10">
                    ${server.online ? 'Connect' : 'Offline'}
                </button>
            </div>
        `;
    } else if (layout === 'secondary') {
        // Medium server cards (Delhi Nodes #3, #4, #5)
        return `
            <div class="server-entry p-5 rounded-lg ${offlineClass}" data-ip="${server.ip}">
                <div class="map-overlay" style="background-image: url('${mapImage}');"></div>
                <h4 class="font-bold text-xs text-white uppercase relative z-10">${server.name}</h4>
                <p class="text-[9px] text-zinc-500 font-mono relative z-10 mb-4">${server.ip}</p>
                ${server.online ? `
                    <div class="flex justify-between items-center mb-4 relative z-10">
                        <span class="text-[10px] text-zinc-600">Players: <span class="player-count ${playerColor} font-black">${server.players}/${server.maxPlayers}</span></span>
                        <span class="text-[10px] text-zinc-600">${server.map}</span>
                    </div>
                ` : `
                    <div class="mb-4 relative z-10">
                        <span class="text-[10px] players-offline font-black">Server Offline</span>
                    </div>
                `}
                <button onclick="connect('${server.ip}')" class="w-full py-2 text-[9px] font-black uppercase tracking-widest border border-white/5 connect-btn relative z-10">
                    ${server.online ? 'Connect' : 'Offline'}
                </button>
            </div>
        `;
    } else {
        // Global server layout
        return `
            <div class="server-entry p-6 rounded-lg flex justify-between items-center ${offlineClass}" data-ip="${server.ip}">
                <div class="map-overlay" style="background-image: url('${mapImage}');"></div>
                <div class="relative z-10">
                    <h4 class="font-bold text-xs text-white uppercase">${server.name}</h4>
                    <p class="text-[9px] text-zinc-500 font-mono">${server.ip}</p>
                    ${server.online ? `
                        <div class="flex items-center gap-4 mt-2">
                            <span class="text-[9px] text-zinc-600">Players: <span class="player-count ${playerColor} font-black">${server.players}/${server.maxPlayers}</span></span>
                            <span class="text-[9px] text-zinc-600">${server.map}</span>
                            <span class="text-[9px] text-zinc-600">${server.ping}ms</span>
                        </div>
                    ` : ''}
                </div>
                <button onclick="connect('${server.ip}')" class="connect-btn px-6 py-2 text-[9px] font-black uppercase relative z-10">
                    ${server.online ? 'Connect' : 'Offline'}
                </button>
            </div>
        `;
    }
}

/**
 * Fetch server data from API
 * @returns {Promise<Array>} Array of server objects
 */
async function fetchServerData() {
    try {
        const response = await fetch('/api/servers');
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching server data:', error);
        return [];
    }
}

/**
 * Sort servers by online status (online first, offline last)
 * @param {Array} servers - Array of server objects
 * @returns {Array} Sorted array of servers
 */
function sortServersByStatus(servers) {
    return servers.sort((a, b) => {
        // Online servers come first
        if (a.online && !b.online) return -1;
        if (!a.online && b.online) return 1;
        // If both have same status, maintain original order
        return 0;
    });
}

/**
 * Render servers to the DOM
 */
async function renderServers() {
    const serverData = await fetchServerData();
    if (!serverData || serverData.length === 0) {
        console.error('No server data available');
        return;
    }

    servers = serverData;

    // Group servers by region
    const conneqtServers = sortServersByStatus(servers.filter(s => s.region === 'conneqt'));
    const delhiServers = sortServersByStatus(servers.filter(s => s.region === 'north'));
    const mumbaiServers = sortServersByStatus(servers.filter(s => s.region === 'west'));
    const globalServers = sortServersByStatus(servers.filter(s => s.region === 'global'));

    // Render Conneqt servers
    const conneqtContainer = document.getElementById('conneqt-servers');
    if (conneqtContainer) {
        let conneqtHTML = '';
        conneqtServers.forEach(server => {
            conneqtHTML += createServerElement(server, 'conneqt');
        });
        conneqtContainer.innerHTML = conneqtHTML;
    }

    // Render Delhi servers
    const delhiContainer = document.getElementById('delhi-servers');
    if (delhiContainer) {
        let delhiHTML = '';
        
        // Primary servers (first 2)
        delhiServers.slice(0, 2).forEach(server => {
            delhiHTML += createServerElement(server, 'primary');
        });
        
        // Secondary servers (remaining)
        if (delhiServers.length > 2) {
            delhiHTML += '<div class="grid grid-cols-1 md:grid-cols-3 gap-4 mt-2">';
            delhiServers.slice(2).forEach(server => {
                delhiHTML += createServerElement(server, 'secondary');
            });
            delhiHTML += '</div>';
        }
        
        delhiContainer.innerHTML = delhiHTML;
    }

    // Render Mumbai servers
    const mumbaiContainer = document.getElementById('mumbai-servers');
    if (mumbaiContainer) {
        let mumbaiHTML = '';
        mumbaiServers.forEach(server => {
            mumbaiHTML += createServerElement(server, 'secondary');
        });
        mumbaiContainer.innerHTML = mumbaiHTML;
    }

    // Render Global servers
    const globalContainer = document.getElementById('global-servers');
    if (globalContainer) {
        let globalHTML = '';
        globalServers.forEach(server => {
            globalHTML += createServerElement(server, 'global');
        });
        globalContainer.innerHTML = globalHTML;
    }
}

/**
 * Update refresh timer display
 */
function updateRefreshTimer() {
    const timerElement = document.getElementById('refresh-timer');
    if (timerElement) {
        timerElement.textContent = `${refreshTimer}s`;
    }
    
    refreshTimer--;
    if (refreshTimer < 0) {
        refreshTimer = 20;
    }
}

/**
 * Start auto-refresh
 */
function startAutoRefresh() {
    // Clear existing interval
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
    
    // Update timer every second
    refreshInterval = setInterval(() => {
        updateRefreshTimer();
        
        // Refresh servers when timer reaches 0
        if (refreshTimer === 19) {
            renderServers();
        }
    }, 1000);
}

/**
 * Manual refresh
 */
function manualRefresh() {
    refreshTimer = 20;
    renderServers();
    
    // Visual feedback
    const refreshBtn = document.querySelector('button[onclick="manualRefresh()"]');
    if (refreshBtn) {
        refreshBtn.innerHTML = '<i class="fas fa-sync-alt fa-spin mr-1"></i> Refreshing...';
        setTimeout(() => {
            refreshBtn.innerHTML = '<i class="fas fa-sync-alt mr-1"></i> Refresh';
        }, 1000);
    }
}

/**
 * Show page (navigation)
 * @param {string} pageId - Page ID to show
 */
function showPage(pageId) {
    document.getElementById('page-dashboard').classList.add('hidden');
    document.getElementById('page-stats').classList.add('hidden');
    document.getElementById('nav-dash').classList.remove('active');
    document.getElementById('nav-stats').classList.remove('active');
    document.getElementById(`page-${pageId}`).classList.remove('hidden');
    document.getElementById(`nav-${pageId === 'dashboard' ? 'dash' : 'stats'}`).classList.add('active');
    
    // Start auto-refresh when dashboard is shown
    if (pageId === 'dashboard') {
        startAutoRefresh();
        renderServers();
    } else {
        // Stop auto-refresh when not on dashboard
        if (refreshInterval) {
            clearInterval(refreshInterval);
        }
    }
}

/**
 * Connect to server
 * @param {string} ip - Server IP and port
 */
function connect(ip) {
    const loader = document.getElementById('loader');
    const loaderIp = document.getElementById('loader-ip');
    
    loader.classList.remove('hidden');
    loader.classList.add('flex');
    loaderIp.innerText = `ROUTING TO: ${ip}`;
    
    setTimeout(() => { 
        window.location.href = `steam://connect/${ip}`; 
    }, 1500);
    
    setTimeout(() => { 
        loader.classList.add('hidden'); 
    }, 3000);
}

/**
 * Search player (placeholder function)
 */
function searchPlayer() {
    const input = document.getElementById('steam-search-input').value;
    if (!input) return;
    
    const loader = document.getElementById('loader');
    loader.classList.remove('hidden');
    loader.classList.add('flex');
    
    setTimeout(() => {
        loader.classList.add('hidden');
        document.getElementById('stats-welcome').classList.add('hidden');
        document.getElementById('stats-dashboard').classList.remove('hidden');
        document.getElementById('player-name').innerText = input;
        document.getElementById('stat-kills').innerText = "4,210";
        document.getElementById('stat-winrate').innerText = "51.8%";
        document.getElementById('stat-kd').innerText = "1.12";
    }, 1200);
}

/**
 * Handle Steam login (placeholder function)
 */
function handleSteamLogin() { 
    searchPlayer(); 
}

/**
 * Initialize the application
 */
async function init() {
    // Show loading state
    const conneqtContainer = document.getElementById('conneqt-servers');
    const delhiContainer = document.getElementById('delhi-servers');
    const mumbaiContainer = document.getElementById('mumbai-servers');
    const globalContainer = document.getElementById('global-servers');
    
    if (conneqtContainer) {
        conneqtContainer.innerHTML = '<div class="text-center py-8"><p class="text-zinc-500 loading-text">Fetching server data...</p></div>';
    }
    if (delhiContainer) {
        delhiContainer.innerHTML = '<div class="text-center py-8"><p class="text-zinc-500 loading-text">Fetching server data...</p></div>';
    }
    if (mumbaiContainer) {
        mumbaiContainer.innerHTML = '<div class="text-center py-8"><p class="text-zinc-500 loading-text">Fetching server data...</p></div>';
    }
    if (globalContainer) {
        globalContainer.innerHTML = '<div class="text-center py-8"><p class="text-zinc-500 loading-text">Fetching server data...</p></div>';
    }
    
    // Initial render
    await renderServers();
    
    // Start auto-refresh
    startAutoRefresh();
}

// Initialize when DOM is loaded
document.addEventListener('DOMContentLoaded', init);

// Clean up on page unload
window.addEventListener('beforeunload', () => {
    if (refreshInterval) {
        clearInterval(refreshInterval);
    }
});
