const express = require('express');
const Gamedig = require('gamedig');
const cors = require('cors');
const NodeCache = require('node-cache');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// Cache configuration - 15 seconds TTL
const serverCache = new NodeCache({ stdTTL: 15, checkperiod: 10 });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Server list configuration extracted from HTML
const SERVERS = [
    // Conneqt Servers - Priority Section
    { name: "Conneqt #1", ip: "49.205.172.5:27017", region: "conneqt", type: "conneqt" },
    { name: "Conneqt #2", ip: "124.123.100.173:27028", region: "conneqt", type: "conneqt" },
    { name: "Conneqt #3", ip: "49.205.172.5:27016", region: "conneqt", type: "conneqt" },
    { name: "Conneqt #4", ip: "124.123.100.173:27025", region: "conneqt", type: "conneqt" },
    { name: "Conneqt #5", ip: "49.205.172.5:27021", region: "conneqt", type: "conneqt" },
    { name: "Conneqt #6", ip: "140.245.194.234:27016", region: "conneqt", type: "conneqt" },
    { name: "Conneqt #7", ip: "49.205.172.5:27018", region: "conneqt", type: "conneqt" },
    
    // Delhi Hub - North Region
    { name: "Delhi Primary #1", ip: "49.205.172.5:27019", region: "north", type: "primary" },
    { name: "Delhi Primary #2", ip: "49.205.172.5:27020", region: "north", type: "primary" },
    { name: "Delhi Node #3", ip: "49.205.172.5:27016", region: "north", type: "secondary" },
    { name: "Delhi Node #4", ip: "49.205.172.5:27018", region: "north", type: "secondary" },
    { name: "Delhi Alt #5", ip: "95.135.0.130:27020", region: "north", type: "secondary" },
    
    // Mumbai Hub - West Region
    { name: "Mumbai #1", ip: "163.223.52.142:27015", region: "west", type: "primary" },
    { name: "Mumbai #2", ip: "163.223.52.142:28015", region: "west", type: "primary" },
    { name: "Mumbai #3", ip: "23.111.15.107:27055", region: "west", type: "primary" },
    
    // Global Servers
    { name: "GEN NODE 01", ip: "20.174.11.180:27015", region: "global", type: "global" },
    { name: "GEN NODE 02", ip: "20.47.95.74:27075", region: "global", type: "global" },
    { name: "GEN NODE 03", ip: "163.227.239.213:27015", region: "global", type: "global" },
    { name: "GEN NODE 04", ip: "15.235.233.145:27054", region: "global", type: "global" }
];

/**
 * Query a single CS:GO/CS2 server using gamedig
 * @param {string} ipPort - Server IP and port (e.g., "192.168.1.1:27015")
 * @returns {Promise<Object>} Server information
 */
async function queryServer(ipPort) {
    try {
        const [host, port] = ipPort.split(':');
        
        const result = await Gamedig.query({
            type: 'csgo', // Works for both CS:GO and CS2
            host: host,
            port: parseInt(port),
            maxAttempts: 2,
            socketTimeout: 3000,
            givenPortOnly: true
        });

        return {
            online: true,
            name: result.name || 'Unknown Server',
            map: result.map || 'unknown',
            players: result.players.length || 0,
            maxPlayers: result.maxplayers || 0,
            ping: result.ping || 0,
            bots: result.bots || 0
        };
    } catch (error) {
        console.log(`Server ${ipPort} query failed: ${error.message}`);
        return {
            online: false
        };
    }
}

/**
 * Get server data with caching
 * @param {string} ipPort - Server IP and port
 * @returns {Promise<Object>} Server information
 */
async function getServerData(ipPort) {
    // Check cache first
    const cachedData = serverCache.get(ipPort);
    if (cachedData) {
        return cachedData;
    }

    // Query server if not in cache
    const serverData = await queryServer(ipPort);
    
    // Cache the result
    serverCache.set(ipPort, serverData);
    
    return serverData;
}

// API Routes

/**
 * GET /api/server/:ip
 * Get information for a specific server
 */
app.get('/api/server/:ip', async (req, res) => {
    try {
        const ip = req.params.ip;
        
        if (!ip) {
            return res.status(400).json({ error: 'Server IP is required' });
        }

        const serverData = await getServerData(ip);
        res.json(serverData);
    } catch (error) {
        console.error('Error in /api/server/:ip:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/servers
 * Get information for all servers
 */
app.get('/api/servers', async (req, res) => {
    try {
        const serverPromises = SERVERS.map(async (server) => {
            const data = await getServerData(server.ip);
            return {
                ...server,
                ...data
            };
        });

        const servers = await Promise.all(serverPromises);
        res.json(servers);
    } catch (error) {
        console.error('Error in /api/servers:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/servers/region/:region
 * Get servers by region (north, west, global)
 */
app.get('/api/servers/region/:region', async (req, res) => {
    try {
        const region = req.params.region;
        const filteredServers = SERVERS.filter(server => server.region === region);
        
        const serverPromises = filteredServers.map(async (server) => {
            const data = await getServerData(server.ip);
            return {
                ...server,
                ...data
            };
        });

        const servers = await Promise.all(serverPromises);
        res.json(servers);
    } catch (error) {
        console.error('Error in /api/servers/region/:region:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

/**
 * GET /api/servers/config
 * Get server configuration (names and IPs only)
 */
app.get('/api/servers/config', (req, res) => {
    try {
        res.json(SERVERS);
    } catch (error) {
        console.error('Error in /api/servers/config:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Health check endpoint
app.get('/api/health', (req, res) => {
    res.json({ 
        status: 'ok', 
        timestamp: new Date().toISOString(),
        cache_stats: serverCache.getStats()
    });
});

// Serve the main HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Error handling middleware
app.use((err, req, res, next) => {
    console.error('Unhandled error:', err);
    res.status(500).json({ error: 'Internal server error' });
});

// 404 handler
app.use((req, res) => {
    res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
app.listen(PORT, () => {
    console.log(`🚀 CS:GO/CS2 Server Browser running on http://localhost:${PORT}`);
    console.log(`📊 API endpoints available:`);
    console.log(`   GET /api/server/:ip - Get single server info`);
    console.log(`   GET /api/servers - Get all servers`);
    console.log(`   GET /api/servers/region/:region - Get servers by region`);
    console.log(`   GET /api/servers/config - Get server configuration`);
    console.log(`   GET /api/health - Health check`);
    console.log(`🕐 Cache TTL: 15 seconds`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    serverCache.close();
    process.exit(0);
});

process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    serverCache.close();
    process.exit(0);
});
