# ADU CS:GO/CS2 Server Browser Dashboard

A production-ready server browser dashboard for CS:GO and CS2 servers with real-time data fetching, auto-refresh, and professional UI.

## Features

### Backend (Node.js + Express)
- **Real-time server querying** using `gamedig` npm package
- **15-second caching** to prevent spam queries
- **Multiple API endpoints** for flexible data access
- **Error handling** for timeouts and invalid IPs
- **Health check** endpoint for monitoring

### Frontend (HTML + JavaScript)
- **Dynamic server rendering** - No hardcoded HTML
- **Real-time data fetching** with loading states
- **Auto-refresh every 20 seconds** with visual timer
- **Color-coded player counts** (Green/Yellow/Red)
- **Offline server detection** and styling
- **Smooth transitions** and hover effects
- **Original ADU UI design** preserved exactly

### API Endpoints

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/server/:ip` | GET | Get single server info |
| `/api/servers` | GET | Get all servers with real data |
| `/api/servers/region/:region` | GET | Get servers by region (north/west/global) |
| `/api/servers/config` | GET | Get server configuration (names/IPs only) |
| `/api/health` | GET | Health check with cache stats |

## Folder Structure

```
csgo-server-browser/
├── package.json              # Dependencies and scripts
├── server.js                 # Backend server (Express + gamedig)
├── README.md                 # This file
└── public/
    ├── index.html            # Frontend HTML (updated)
    └── script.js             # Frontend JavaScript (dynamic rendering)
```

## Installation & Setup

### Prerequisites
- Node.js 16.0.0 or higher
- npm or yarn package manager

### Step 1: Install Dependencies
```bash
cd csgo-server-browser
npm install
```

### Step 2: Start the Server
```bash
npm start
```

Or for development with auto-restart:
```bash
npm run dev
```

### Step 3: Access the Dashboard
Open your browser and navigate to:
```
http://localhost:3000
```

## Usage

### Dashboard Features
1. **Real-time Server Status**: Live player counts, maps, and ping
2. **Auto-refresh**: Automatically updates every 20 seconds
3. **Manual Refresh**: Click the refresh button for instant updates
4. **Server Connect**: Click "Connect" to join servers via Steam
5. **Regional Grouping**: Servers organized by Delhi, Mumbai, and Global regions

### Color Coding
- 🟢 **Green**: Low player count (< 50% capacity)
- 🟡 **Yellow**: Medium player count (50-80% capacity)
- 🔴 **Red**: High player count (80-100% capacity)
- ⚫ **Gray**: Server offline

### Server Response Format

#### Online Server:
```json
{
  "name": "Delhi Primary #1",
  "map": "de_dust2",
  "players": 10,
  "maxPlayers": 20,
  "ping": 45,
  "online": true,
  "bots": 0
}
```

#### Offline Server:
```json
{
  "online": false
}
```

## Configuration

### Adding/Removing Servers
Edit the `SERVERS` array in `server.js`:

```javascript
const SERVERS = [
    { 
        name: "Server Name", 
        ip: "192.168.1.1:27015", 
        region: "north", // north, west, global
        type: "primary"   // primary, secondary, global
    },
    // Add more servers...
];
```

### Cache Configuration
Modify cache settings in `server.js`:
```javascript
const serverCache = new NodeCache({ 
    stdTTL: 15,    // Cache duration in seconds
    checkperiod: 10 // Cleanup interval
});
```

### Auto-refresh Interval
Change the refresh timing in `public/script.js`:
```javascript
let refreshTimer = 20; // Seconds
```

## Development

### Project Structure
- **server.js**: Express backend with gamedig integration
- **public/index.html**: Frontend UI (preserved original design)
- **public/script.js**: Dynamic rendering and real-time updates

### Key Features Implemented
1. **Backend**: Complete Express server with gamedig
2. **Caching**: 15-second TTL to prevent query spam
3. **Error Handling**: Graceful offline server detection
4. **Dynamic Rendering**: No hardcoded server HTML
5. **Auto-refresh**: 20-second intervals with timer
6. **Color Logic**: Player count-based coloring
7. **Loading States**: Smooth loading animations
8. **Original UI**: Exact design preservation

### Environment Variables
Optional environment variables:
- `PORT`: Server port (default: 3000)

## Troubleshooting

### Common Issues

1. **Servers showing as offline**
   - Check if servers are actually online
   - Verify IP addresses and ports are correct
   - Check network connectivity

2. **Slow loading times**
   - Adjust cache TTL in `server.js`
   - Check server response times
   - Verify network connectivity to game servers

3. **Steam connect not working**
   - Ensure Steam is installed and running
   - Check if CS:GO/CS2 is installed
   - Verify server IP format (IP:PORT)

### API Testing
Test endpoints directly:
```bash
# Get all servers
curl http://localhost:3000/api/servers

# Get specific server
curl http://localhost:3000/api/server/49.205.172.5:27019

# Health check
curl http://localhost:3000/api/health
```

## Performance

### Optimization Features
- **Caching**: 15-second cache reduces server queries
- **Batch Processing**: All servers queried in parallel
- **Error Handling**: Failed queries don't block others
- **Lightweight**: Minimal dependencies and fast response

### Expected Performance
- **Initial Load**: 2-5 seconds (first-time queries)
- **Cached Response**: < 500ms
- **Auto-refresh**: Seamless background updates
- **Memory Usage**: < 50MB for cache

## License

MIT License - Feel free to use and modify for your own CS:GO/CS2 communities.

## Support

For support:
- Discord: immortal_xyz
- Check console for error messages
- Verify server IPs are accessible from your network

---

**Built with ❤️ for the Indian CS:GO/CS2 Community**
