# ADU CS:GO Server Browser Launcher
# PowerShell script for starting the server and opening browser

Write-Host "========================================" -ForegroundColor Green
Write-Host "   ADU CS:GO Server Browser Launcher" -ForegroundColor Yellow
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Check if dependencies are installed
Write-Host "[1/3] Checking dependencies..." -ForegroundColor Cyan

if (-not (Test-Path "node_modules")) {
    Write-Host "[!] Dependencies not found. Installing now..." -ForegroundColor Yellow
    Write-Host ""
    npm install
    
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[ERROR] Failed to install dependencies!" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }
    Write-Host "[✓] Dependencies installed successfully!" -ForegroundColor Green
} else {
    Write-Host "[✓] Dependencies already installed" -ForegroundColor Green
}

Write-Host ""
Write-Host "[2/3] Starting server..." -ForegroundColor Cyan
Write-Host ""

# Start the server in background
$serverProcess = Start-Process -FilePath "node" -ArgumentList "server.js" -PassThru -WindowStyle Minimized

# Wait for server to start
Write-Host "Waiting for server to initialize..."
Start-Sleep -Seconds 3

Write-Host ""
Write-Host "[3/3] Opening browser..." -ForegroundColor Cyan
Write-Host ""

# Open in default browser
Start-Process "http://localhost:3000"

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "[✓] ADU Server Browser is running!" -ForegroundColor Yellow
Write-Host "   Server: http://localhost:3000" -ForegroundColor White
Write-Host "   Press Ctrl+C to stop server..." -ForegroundColor White
Write-Host "========================================" -ForegroundColor Green
Write-Host ""

# Wait for user to stop
try {
    while ($true) {
        Start-Sleep -Seconds 1
    }
}
finally {
    Write-Host ""
    Write-Host "[!] Stopping server..." -ForegroundColor Yellow
    Stop-Process -Id $serverProcess.Id -Force -ErrorAction SilentlyContinue
    Write-Host "[✓] Server stopped. Goodbye!" -ForegroundColor Green
    Start-Sleep -Seconds 2
}
